<?php

    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Cache-Control: must-revalidate');
    header('Content-Disposition: attachment; filename="blocks.dat"');
    header('Content-Length: ' . filesize('/srv/.vfc/blocks.dat'));
    readfile('/srv/.vfc/blocks.dat');
    //header('Location: http://46.4.183.153/blocks.dat');

?>