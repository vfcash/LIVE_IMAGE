<?php

    function hashSanity($hash)
    {
        return str_replace('O', '', str_replace('0', '', str_replace('l', '', preg_replace("/[^A-Za-z0-9]/", '', $hash))));
    }

    function strSanity($str)
    {
        return preg_replace("/[^A-Za-z0-9 ]/", '', $str);
    }

    //Functions
    function getBalance($public_key)
    {
        $public_key = str_replace(' ', '', $public_key);
        if(strlen($public_key) > 12)
        {
            $na = shell_exec('/usr/bin/vfc ' . escapeshellarg($public_key));
            $p = strstr($na, "Final Balance: ");
            $p = str_replace("Final Balance: ", "", $p);
            return explode(" ", $p, 2)[0];
        }
    }

    //Get public key from private key
    function getPub($private_key)
    {
        $na = shell_exec('/usr/bin/vfc getpub ' . escapeshellarg($private_key));
        $p = strstr($na, "Public: ");
        $p = str_replace("Public: ", "", $p);
        return explode("\n", $p, 2)[0];
    }

    //Logout
    if(isset($_GET['logout']))
    {
        $_SESSION['pub'] = "Not Logged In";
        unset($_SESSION['priv']);
        header('Location: /wallet');
        exit;
    }

    //Login
    if(isset($_POST['vfcprivkey']))
    {
        $priv = hashSanity($_POST['vfcprivkey']);
        $pub = getPub($priv);

        if(getBalance($pub) < $_GET['vfc'])
        {
            header('Location: /transfer/failed.htm');
            exit;
        }

        shell_exec('/usr/bin/vfc ' . escapeshellarg($pub) . ' ' . escapeshellarg(hashSanity($_GET['to'])) . ' ' . escapeshellarg(floatval($_GET['vfc'])) . ' ' . escapeshellarg($priv));
        
        header('Location: /transfer/sent.htm');
        exit;
    }

?>
<!doctype html>
<html lang="en">
<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#ffbf00">
    <meta name="revisit-after" content="30 days" />
    <meta name="robots" content="index, follow, noarchive" />
    <title>VF Cash Payment Authorization</title>

    <link rel="shortcut icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="https://vfcash.uk/favicon.png">
    <link rel="icon" sizes="192x192" href="https://vfcash.uk/favicon.png">
    
    <meta property="og:image" content="https://vfcash.uk/vf.png">
    <meta property="twitter:image:src" content="https://vfcash.uk/vf.png">
    <meta name="image" content="https://vfcash.uk/vf.png">
    <meta itemprop="image" content="https://vfcash.uk/vf.png">
    <meta name="og:image" content="https://vfcash.uk/vf.png">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    <style>
    body{font-family: 'Ubuntu', sans-serif;}
    </style>

</head>
<body>

    <div class="container">

    <nav class="navbar navbar-expand-md navbar-light bg-light">

        <a href="https://vfcash.uk"><img src="//vfcash.uk/light-horiz.svg" width="auto" height="32px" /></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

    </nav>

        <hr>
        <br>
        <center>
        <h3 class="text-success"><b>Would you like to authorize a payment of<b></h3>
        <h4>
        <?php echo number_format($_GET['vfc'], 3); ?> <b>VFC</b><br><hr style="width:30%;">To the Address:<br><b><?php echo htmlspecialchars($_GET['to']); ?></b>
        </h4>
        </center>
        <br>
        <hr>

    <form id="transform" action="index.php?to=<?php echo htmlspecialchars($_GET['to']); ?>&vfc=<?php echo htmlspecialchars($_GET['vfc']); ?>" method="post">
        <div class="input-group">
            <input name="vfcprivkey" class="form-control" type="password" placeholder="<private key>" required> <button type="submit" id="sendvfc" class="btn btn-primary"><b>Authorize Payment</b></button>
        </div>
    </form>

        <hr>

    <br><br>

    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
    $(function()
    {
        if(self == top)
        {
            document.documentElement.style.display = 'block'; 
        }
        else
        {
            top.location = self.location; 
        }

        if(window.history.replaceState)
            window.history.replaceState(null, null, window.location.href);

        $('#transform').on('submit', function(e)
        {
            tt('#sendvfc');
        });

        $('[data-toggle="tooltip"]').tooltip();
    })

    function tt(name)
    {
        $(name).prop('disabled', true);
        $(name).text('Sending...');
    }

    </script>

</body>
</html>