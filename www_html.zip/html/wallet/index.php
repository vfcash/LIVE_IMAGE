<?php

    //Start a session
    session_start();
    $fb1 = 0;
    $fb0 = 0;

    // throttle
    if(isset($_SESSION['lq']))
    {
        while(time() < $_SESSION['lq'])
            sleep(1);
    }

    //Get Balance
    function getBalance($public_key)
    {
        $public_key = str_replace(' ', '', $public_key);
        if(strlen($public_key) > 12)
        {
            $na = shell_exec('/usr/bin/vfc ' . escapeshellarg($public_key));
            $p = strstr($na, "Final Balance: ");
            $p = str_replace("Final Balance: ", "", $p);
            return explode(" ", $p, 2)[0];
        }
    }

    //Get public key from private key
    function getPub($private_key)
    {
        $na = shell_exec('/usr/bin/vfc getpub ' . escapeshellarg($private_key));
        $p = strstr($na, "Public: ");
        $p = str_replace("Public: ", "", $p);
        return explode("\n", $p, 2)[0];
    }

    // sanitise
    function strSanity($str)
    {
        return str_replace('O', '', str_replace('0', '', str_replace('l', '', preg_replace("/[^A-Za-z0-9]/", '', $str))));
    }

    function hashSanity($hash)
    {
        return str_replace('O', '', str_replace('0', '', str_replace('l', '', preg_replace("/[^A-Za-z0-9]/", '', $hash))));
    }

    function isBase58($key)
    {
        if(ctype_alnum($key) === false || strpos($key, "O") !== false || strpos($key, "0") !== false || strpos($key, "l") !== false)
            return false;
        return true;
    }

    //Make Transaction
    $txid = '';
    $invalid = 0;
    if(isset($_POST['sto']) && isset($_SESSION['pub']))
    {
        $send_to = hashSanity($_POST['sto']);
        $send_amount = floatval($_POST['sa']);

        $fb0 = getBalance($_SESSION['pub']);
        if($send_amount <= 0 || $send_amount > $fb0 || $_SESSION['pub'] == $send_to || $send_to == "")
        {
            $invalid = 1;
        }
        else
        {
            $_SESSION['lq'] = time()+3;
            $m = new Memcached();
            $m->addServer("127.0.0.1", 11211);
            if($m->get(sha1($_SESSION['pub'].'/'.$send_to.'/'.$send_amount)) != "n")
            {
                $m->add(sha1($_SESSION['pub'].'/'.$send_to.'/'.$send_amount), "n", 360);
            
                $dat = shell_exec('/usr/bin/vfc ' . escapeshellarg($_SESSION['pub']) . ' ' . escapeshellarg($send_to) . ' ' . escapeshellarg($send_amount) . ' ' . escapeshellarg($_SESSION['priv']));
                //file_put_contents('wtf.txt', '/usr/bin/vfc ' . escapeshellarg($_SESSION['pub']) . ' ' . escapeshellarg($send_to) . ' ' . escapeshellarg($send_amount) . ' ' . escapeshellarg($_SESSION['priv']) . "\n", FILE_APPEND | LOCK_EX);

                //set txid
                $s = strstr($dat, "...\n");
                $txid = str_replace("...\n", "", explode(':', $s, 2)[0]);

                $fb1 = $fb0;
                $st = 0;
                while($fb1 == $fb0)
                {
                    if($st > 10)
                        break;
                    
                    $fb1 = getBalance($_SESSION['pub']);
                    Sleep(1);
                    $st++;
                }
            }
            else
            {
                $fb0 = -1;
                $fb1 = -1;
            }
            $m->quit();
        }
    }

    //Get Top Transactions
    function printTops($public_key, $num)
    {
        $_SESSION['lq'] = time()+1;
        $na = shell_exec('/usr/bin/vfc top ' . escapeshellarg($public_key) . ' ' . $num);

        $p = explode("\n", $na);
        $t = 0;
        foreach($p as $pc)
        {
            if($pc == '')
                continue;

            $a = explode(',', $pc);
            if(count($a) == 4)
            {
                $t += $a[3];
                if($a[0] == 'OUT')
                    echo '<tr><td style="color:#e83e8c;">sent</td><td>' . $a[2] . '</td><td>' . number_format($a[3], 3) . '</td></tr>';
                else
                    echo '<tr><td style="color:#20c997;">recv</td><td>' . $a[2] . '</td><td>' . number_format($a[3], 3) . '</td></tr>';
            }
        }
        $_SESSION['lq'] = time()+1;
    }

    //New
    $na = shell_exec('/usr/bin/vfc new');
    $p = strstr($na, "Private: ");
    $p = str_replace('Private: ', '', $p);
    $newpriv = explode("\n", $p, 2)[0];

    //Logout
    if(isset($_GET['logout']))
    {
        $_SESSION['pub'] = "Not Logged In";
        unset($_SESSION['priv']);
        header('Location: /wallet/');
        exit;
    }

    //Login
    if(isset($_POST['privkey']) && $_POST['privkey'] != "" && !isset($_SESSION['priv']))
    {
        // validate login input
        if(isBase58($_POST['privkey']) === false)
        {
            $_SESSION['pub'] = "Not Logged In";
            unset($_SESSION['priv']);
            header('Location: /wallet/');
            exit;
        }

        $_SESSION['priv'] = hashSanity($_POST['privkey']);
        $_SESSION['pub'] = getPub($_SESSION['priv']);
        header('Location: /wallet/');
        exit;
    }
    else if(isset($_POST['privkey']) && $_POST['privkey'] != "" && $_SESSION['pub'] != "Not Logged In")
    {
        $_SESSION['pub'] = "Not Logged In";
        unset($_SESSION['priv']);
        header('Location: /wallet/');
        exit;
    }

    //echo $_SESSION['pub'] . " - " . $_POST['privkey'];
    // exit;

    if(!isset($_SESSION['pub']))
        $_SESSION['pub'] = "Not Logged In";

    if(!isset($_SESSION['theme']))
        $_SESSION['theme'] = 0;
    
    if(isset($_GET['theme']))
    {
        $_SESSION['theme'] = !$_SESSION['theme'];
        header('Location: index.php');
        exit;
    }

?>
<!doctype html>
<html lang="en">
<head>
    
    <meta name="darkreader-lock"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="theme-color" content="#ffbf00">
    <meta name="revisit-after" content="30 days" />
    <meta name="robots" content="index, follow, noarchive" />
    <title>VF Wallet</title>

    <link rel="shortcut icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="https://vfcash.uk/favicon.png">
    <link rel="icon" sizes="192x192" href="https://vfcash.uk/favicon.png">
    <meta property="og:image" content="https://vfcash.uk/favicon.png">
    <meta property="twitter:image:src" content="https://vfcash.uk/favicon.png">
    <meta name="image" content="https://vfcash.uk/favicon.png">
    <meta itemprop="image" content="https://vfcash.uk/favicon.png">
    <meta name="og:image" content="https://vfcash.uk/favicon.png">

    <link rel="stylesheet" href="jquery-ui.min.css">
<?php
    if($_SESSION['theme'] == 0)
        echo '<link rel="stylesheet" href="t0.css">';
    else
        echo '<link rel="stylesheet" href="t1.css">';
?>

</head>
<body>
<?php
    if($_SESSION['theme'] == 1)
    {
?>
    <canvas style="position:fixed;left:0;top:0;z-index:-3;" id="bgcan"></canvas>
<?php
    }
?>
    <form id="flogin" action="index.php" method="post">
    <center>
    <button title="Save key before logging in, or you will lose access to the account." onclick="newPriv();" style="width:10%;" type="button">New</button><input id="vfckey" type="text" style="width:70%;font-weight:bold;" name="privkey" autocomplete="on" placeholder="<private key>" <?php if($_SESSION['pub'] == "Not Logged In"){echo 'title="<b style=\'color:#ff0000;\'>PRIVATE KEY</b> never give this to anyone."';}else{echo 'title="<b style=\'color:#00ff00;\'>PUBLIC KEY</b>, this is what you give other people to receive transactions."';} ?> value="<?php if($_SESSION['pub'] != "Not Logged In"){echo $_SESSION['pub'];} ?>"><button id="blogin" style="width:17%;" type="submit">Login</button>
    </center>
    </form>
    <hr>
    <table>
        <tr>
            <th style="width:20%;">Balance</th><th style="text-align:center;" id="ubal">
            <?php
                if(isset($_SESSION['pub']) && $_SESSION['pub'] != "Not Logged In")
                    echo number_format(getBalance($_SESSION['pub']), 3);
                else
                    echo "0";
            ?>
            </th>
        </tr>
    </table>
    <table>
        <tr>
            <th style="font-weight:normal;">QR Code</th>
        </tr>
        <tr><td>
<?php
        if($_SESSION['pub'] != "Not Logged In")
        {
?>
            <center><div id="qrcode" onmouseover="this.title='';"></div></center>
<?php
        }else{
            echo "<center>".$_SESSION['pub']."<div style=\"display:none;\" id=\"qrcode\" hidden></div></center>";
        }
?>
        </td></tr>
    </table>
    <hr>
    <form id="ftrans" action="index.php" method="post">
    <center>
    <input name="sa" style="width:20%;" type="number" min=0.001 step=0.001 value=0.001><input id="sto" name="sto" type="text" style="width:66%;" placeholder="<to public key>"><button id="sendvfc" style="width:11%;" type="submit">Send</button> 
    </center>
    </form>

<?php

    if(isset($_POST['sto']))
    {
        $sa = abs($fb1-$fb0);

        if($invalid == 1)
        {
            echo "<br>Transaction was rejected, you do not have the funds to make this transaction.<br><br>";
        }
        else
        {
            if($fb0 == -1 && $fb1 == -1)
            {
                echo "<br>Transaction was rejected, you cannot make the exact same transaction within a five minute period. Please change the amount or receiver address.<br><br>";
            }
            else
            {
                if($sa == 0)
                    echo "<br>Transaction ID <b><a href=\"https://vfcash.uk/explore/?uid=" . $txid . "\" target=\"_blank\">" . $txid . "</a></b> was sent, due to high server load it may take a few minutes to show, please check sent / outgoing transactions for verification.<br><br>";
                else
                    echo "<br>Transaction Sent: <b>" . number_format($_POST['sa'], 3) . " VFC</b><br>TXID: <b><a href=\"https://vfcash.uk/explore/?uid=" . $txid . "\" target=\"_blank\">" . $txid . "</a><br><br>";
            }
        }
    }

?>
    <hr>
    <div style="overflow:auto;">
        <table id="tops">
            <tr>
                <th>Type</th><th>Address</th><th style="width:20%;">Amount</th>
            </tr>
            <?php if($_SESSION['pub'] != "Not Logged In"){printTops($_SESSION['pub'], 10);} ?>
        </table>
    </div>
    <hr>
    <table>
        <tr>
            <th style="width:10%;"><button onclick="clearMinted();" style="width:auto;height:100%;" type="button">Clear</button></th><th>Hashes Per Second</th><th id="hps">0</th>
        </tr>
    </table>
    <div style="overflow:auto;">
        <table id="minted">
            <tr>
                <th style="font-weight:normal;">Minted Private Key</th><th style="width:20%;font-weight:normal;">Value</th>
            </tr>
        </table>
    </div>
    <hr>

    <a title="VF Cash Homepage" href="https://vfcash.uk/" target="_blank"><img style="width:32px;height:auto;" src="../favicon.png"/></a>
    <img title="Switch theme" onclick="document.location.href='index.php?theme'" style="cursor:pointer;width:32px;height:auto;" src="theme.png"/>

    <?php
        if($newpriv != '')
        {
    ?>
    <div id="newpriv" style="display:none;" hidden><?php echo $newpriv; ?></div>
    <?php
        }
    ?>
    <canvas id="canvas" style="display:none;" hidden></canvas>
    <div id="vfcpubkey" style="display:none;" hidden><?php echo $_SESSION['pub']; ?></div>
    
    <script src="jquery-3.5.1.min.js"></script>
    <script src="jquery-ui.min.js"></script>
    <script src="maintainscroll.jquery.min.js"></script>
    <script src="qrcode.min.js"></script>
    <script src="jsQR.js"></script>

    <script>
        function copyTextToClipboard(text)
        {
            var textArea = document.createElement("textarea");
            textArea.style.position = 'fixed';
            textArea.style.top = 0;
            textArea.style.left = 0;
            textArea.style.width = '2em';
            textArea.style.height = '2em';
            textArea.style.padding = 0;
            textArea.style.border = 'none';
            textArea.style.outline = 'none';
            textArea.style.boxShadow = 'none';
            textArea.style.background = 'transparent';
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
        }

        function selectAll(element)
        {
            if (window.getSelection)
            {
                var sel = window.getSelection();
                sel.removeAllRanges();
                var range = document.createRange();
                range.selectNodeContents(element);
                sel.addRange(range);
            }
            else if(document.selection)
            {
                var textRange = document.body.createTextRange();
                textRange.moveToElementText(element);
                textRange.select();
            }
        }

        function newPriv()
        {
<?php
            if($_SESSION['pub'] == "Not Logged In")
            {
?>
                WarningDialog();
                $("#vfckey").val($("#newpriv").html());
<?php
            }else{echo "LogoutDialog();";}
?>
        }

        function clearMinted()
        {
            $.ui.dialog.prototype._focusTabbable = function(){};
            $('<div></div>').appendTo('body')
            .html('<div>You will lose all of your minted keys, are you sure?</div>').dialog(
            {
                modal: true,
                title: 'Notice',
                zIndex: 10000,
                autoOpen: true,
                width: '300px',
                resizable: false,
                buttons:
                {
                    YES: function()
                    {
                        localStorage.removeItem("minted_table");
                        document.location.href = "index.php";
                        $(this).dialog("close");
                    },
                    Cancel: function()
                    {
                        $(this).dialog("close");
                    }
                },
                close: function(event, ui)
                {
                    $(this).remove();
                }
            });
        };
        
        function LogoutDialog()
        {
            $.ui.dialog.prototype._focusTabbable = function(){};
            $('<div></div>').appendTo('body')
            .html('<div>You need to Logout to create a new account.</div>').dialog(
            {
                modal: true,
                title: 'Notice',
                zIndex: 10000,
                autoOpen: true,
                width: '300px',
                resizable: false,
                buttons:
                {
                    Logout: function()
                    {
                        document.location.href = "index.php?logout";
                        $(this).dialog("close");
                    },
                    OK: function()
                    {
                        $(this).dialog("close");
                    }
                },
                close: function(event, ui)
                {
                    $(this).remove();
                }
            });
        };

        function WarningDialog()
        {
            $.ui.dialog.prototype._focusTabbable = function(){};
            $('<div></div>').appendTo('body')
            .html('<div>You need to make sure that you save this private key:<br><b style="color:#dc3545;word-break:break-all;" onclick="selectAll(this);">' + $("#newpriv").html() + '</b> <a href="#" title="Copies private key to clipboard." onclick="copyTextToClipboard($(\'#newpriv\').html());">[copy]</a><br>or you will lose the account.<br><br>Never share your Private Key with anyone.<br><br>Once you click OK the private key will have been copied into the input for you and all you will need to do is click Login.</div>').dialog(
            {
                modal: true,
                title: 'Notice',
                zIndex: 10000,
                autoOpen: true,
                width: '300px',
                resizable: false,
                buttons:
                {
                    Download: function()
                    {
                        window.open("data:application/octet-stream," + $("#newpriv").html());
                    },
                    OK: function()
                    {
                        $(this).dialog("close");
                    }
                },
                close: function(event, ui)
                {
                    $(this).remove();
                }
            });
        };

        function rid(id)
        {
            $.get('index.php', function(data)
            {
                data = $(data).find(id).html();
                $(id).empty().append(data);
            });
        }

        $(document).tooltip(
        {
            tooltipClass: "tooltip",
            content: function()
            {
                return $(this).prop('title');
            }
        });

        var Module =
        {
            print:(function()
            {
                return function(text)
                {
                    if(arguments.length > 1)
                        text = Array.prototype.slice.call(arguments).join(' ');
                    var p = text.split('|');
                    if(p[0] == 'H')
                    {
                        $('#hps').html(p[1]);
                    }
                    else
                    {
                        $('#minted').append('<tr><td>' + p[1] + '</td><td>' + p[2] + '</td></tr>');
                        localStorage.setItem("minted_table", $("#minted").html());
                    }
                };
            })()
        };

        var fint = 0;
        var lup = 0;
        $(document).mousemove(function()
        {
            if(Date.now() > lup)
            {
                if(fint == 0)
                {
                    fint = 1;
                }
                else
                {
                    rid("#ubal");
                    rid("#tops");
                }

                lup = Date.now() + 6000;
            }
        });

        $(document).ready(function()
        {
            new QRCode(document.getElementById("qrcode"), "<?php echo htmlspecialchars($_SESSION['pub']); ?>");

            if(window.history.replaceState)
                window.history.replaceState(null, null, window.location.href);
            
            var si = localStorage.getItem("minted_table");
            if(si !== null)
                $('#minted').html(si);

<?php
            if($_SESSION['pub'] != "Not Logged In")
            {
?>
                $("#vfckey").prop("readonly", true);
                $("#blogin").html("Logout");
                $("#vfckey").val($("#vfcpubkey").html());
<?php
            }
?>
        });

        $("#ftrans").on("submit", function(e)
        {
            $("#sendvfc").prop('disabled', true);
            $("#sendvfc").html('Sending...');
        });

<?php
    if($_SESSION['pub'] != "Not Logged In")
    {
?>
        var video = document.createElement("video");
        var canvasElement = document.getElementById("canvas");
        var canvas = canvasElement.getContext("2d");

        navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then(function(stream)
        {
            video.srcObject = stream;
            video.setAttribute("playsinline", true); 
            video.play();
            requestAnimationFrame(tick);
        });

        function tick()
        {
            if(video.readyState === video.HAVE_ENOUGH_DATA)
            {
                canvasElement.height = video.videoHeight;
                canvasElement.width = video.videoWidth;
                canvas.drawImage(video, 0, 0, canvasElement.width, canvasElement.height);
                var imageData = canvas.getImageData(0, 0, canvasElement.width, canvasElement.height);
                var code = jsQR(imageData.data, imageData.width, imageData.height, {inversionAttempts: "dontInvert",});
                if(code)
                    $('#sto').val(code.data);
            }
            requestAnimationFrame(tick);
        }
<?php
    }
?>

<?php
    if($_SESSION['theme'] == 1)
    {
?>
var c1=[255,0,0],c2=[0,255,0],rule=[0,1,0,1,0,1,0,1],seed=33;function setPixel(a,e,t,i,g,n,r){index=4*(e+t*a.width),a.data[index+0]=i,a.data[index+1]=g,a.data[index+2]=n,a.data[index+3]=r}function random(){var a=1e4*Math.sin(seed++);return a-Math.floor(a)}function gp(a,e,t){return index=4*(e+t*a.width),a.data[index+0]==c1[0]&&a.data[index+1]==c1[1]&&a.data[index+2]==c1[2]?0:1}function setup(){for(seed=Math.random(),i=0;i<7;++i)rule[i]=Math.floor(2*random());console.log("Rule: "+rule[0].toString()+"."+rule[1].toString()+"."+rule[2].toString()+"."+rule[3].toString()+"."+rule[4].toString()+"."+rule[5].toString()+"."+rule[6].toString()+"."+rule[7].toString()),c1[0]=0,c1[1]=0,c1[2]=0,c2[0]=0,c2[1]=23,c2[2]=0,drawCanvas()}function resizeCanvas(){element.width=window.innerWidth,element.height=window.innerHeight,imageData=c.createImageData(element.width,element.height),drawCanvas()}function drawCanvas(){var a=element.width,e=element.height;for(y=0;y<e;++y)for(x=0;x<a;++x)setPixel(imageData,x,y,c2[0],c2[1],c2[2],255);for(x=0;x<a;++x)r=Math.floor(2*Math.random()),1==r&&setPixel(imageData,x,0,c1[0],c1[1],c1[2],255);var t=Math.floor(8500*Math.random());for(i=0;i<t;++i)setPixel(imageData,Math.floor(Math.random()*a),Math.floor(Math.random()*e),c1[0],c1[1],c1[2],255);for(a--,y=1;y<e;++y)for(x=1;x<a;++x)1==rule[0]&&1==gp(imageData,x-1,y-1)&&1==gp(imageData,x,y-1)&&1==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255),1==rule[1]&&1==gp(imageData,x-1,y-1)&&1==gp(imageData,x,y-1)&&0==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255),1==rule[2]&&1==gp(imageData,x-1,y-1)&&0==gp(imageData,x,y-1)&&1==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255),1==rule[3]&&1==gp(imageData,x-1,y-1)&&0==gp(imageData,x,y-1)&&0==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255),1==rule[4]&&0==gp(imageData,x-1,y-1)&&1==gp(imageData,x,y-1)&&1==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255),1==rule[5]&&0==gp(imageData,x-1,y-1)&&1==gp(imageData,x,y-1)&&0==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255),1==rule[6]&&0==gp(imageData,x-1,y-1)&&0==gp(imageData,x,y-1)&&1==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255),1==rule[7]&&0==gp(imageData,x-1,y-1)&&0==gp(imageData,x,y-1)&&0==gp(imageData,x+1,y-1)&&setPixel(imageData,x,y,c1[0],c1[1],c1[2],255);c.putImageData(imageData,0,0)}element=document.getElementById("bgcan"),c=element.getContext("2d"),window.addEventListener("resize",resizeCanvas,!1),resizeCanvas(),setup();
<?php
    }
?>
    </script>
    <script async src="miner.js"></script>

</body>
</html>

