<?php

    //Start a session
    session_start();


    function hashSanity($hash)
    {
        return str_replace('O', '', str_replace('0', '', str_replace('l', '', preg_replace("/[^A-Za-z0-9]/", '', $hash))));
    }

    function strSanity($str)
    {
        return preg_replace("/[^A-Za-z0-9 ]/", '', $str);
    }


    if(isset($_SESSION['lq']))
    {
        if(time() < $_SESSION['lq'])
        {
            $delta = $_SESSION['lq']-time();
            if($delta <= 3)
            {
                while(time() < $_SESSION['lq'])
                    sleep(1);
            }
            else
            {
                echo "please wait " . abs($delta) . " seconds<meta http-equiv=\"refresh\" content=\"3\">";
                exit;
            }
        }
    }

    //Functions
    function getBalance($public_key)
    {
        $public_key = str_replace(' ', '', $public_key);
        if(strlen($public_key) > 12)
        {
            $na = shell_exec('/usr/bin/vfc ' . escapeshellarg($public_key));
            $p = strstr($na, "Final Balance: ");
            $p = str_replace("Final Balance: ", "", $p);
            return explode(" ", $p, 2)[0];
        }
    }

    //Get Transactions
    $out = '';
    $in = '';
    $score = 0;
    $bad = 0;
    function getStatement($public_key)
    {
        GLOBAL $out, $in, $score, $bad;

        $_SESSION['lq'] = time()+3;

        $na = shell_exec('/usr/bin/vfc all ' . escapeshellarg($public_key));
        $lines = explode(PHP_EOL, $na);
        $ti = 0;
        $to = 0;
        foreach($lines as $l)
        {
            if($l == "")
                continue;
                
            $p = explode(',', $l);


            $sati = 'src="non.png" title="Not Rated / Neutral"';

            if(file_exists('reviews/' . $p[1]))
            {
                $r = file_get_contents('reviews/' . $p[1]);

                if($r == 0){$sati = 'src="non.png" title="Not Rated / Neutral"';}
                if($r == 1){$sati = 'src="nsat.png" title="Failed to provide service"'; if($p[0] == "IN"){$bad++;}}
                if($r == 2){$sati = 'src="sat.png" title="Satisfied with service"'; if($p[0] == "IN"){$score++;}}
                if($r == 3){$sati = 'src="vsat.png" title="Very Satisfied with service"'; if($p[0] == "IN"){$score += 2;}}
            }
            
            if($p[0] == "IN")
            {
                $in .= '<tr><td class="min"><a href="rate.php?txid='.$p[1].'"><img width="24px" height="24px" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" ' . $sati . ' /></a></td><th><a data-toggle="tooltip" data-placement="bottom" title="TXID: '.$p[1].'" href="/explore/?addr=' . $p[2] . '"><b style="word-break:break-all;">' . $p[2] . '</b></a></th><td class="min">' . number_format($p[3], 3) . '</td></tr>';
                $ti += $p[3];
            }
            else
            {
                $out .= '<tr><td class="min"><a href="rate.php?txid='.$p[1].'"><img width="24px" height="24px" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" ' . $sati . ' /></a></td><th><a data-toggle="tooltip" data-placement="bottom" title="TXID: '.$p[1].'" href="/explore/?addr=' . $p[2] . '"><b style="word-break:break-all;">' . $p[2] . '</b></a></th><td class="min">' . number_format($p[3], 3) . '</td></tr>';
                $to += $p[3];
            }
        }
        $in .= '<tr><td class="min"></td><th>Total</th><td class="min">' . number_format($ti, 3) . '</td></tr>';
        $out .= '<tr><td class="min"></td><th>Total</th><td class="min">' . number_format($to, 3) . '</td></tr>';

        //Set score color
        if($score > $ti)
            $score = '<b class="text-info">' . $score . '</b>';
        else if($score > 0)
            $score = '<b class="text-success">' . $score . '</b>';
        else if($score == 0)
            $score = '';

        $_SESSION['lq'] = time()+3;
    }

    if(isset($_POST['ledger']))
    {
        header('Location: /explore/?addr='.urlencode($_POST['ledger']));
        exit;
    }

    $addr = 'Address';
    if(isset($_GET['addr']))
        $addr = hashSanity($_GET['addr']);
    
    if(isset($_GET['txid']))
        $_GET['uid'] = strSanity($_GET['txid']);

    if($addr == '111111111111111111111111111111111')
        $addr = 'Address';

    $ruid = '';
    if(isset($_GET['uid']))
    {
        $ruid = shell_exec('/usr/bin/vfc findtrans ' . escapeshellarg($_GET['uid']));
        @$_GET['addr'] = explode(',', $ruid, 4)[2];
        $addr = $_GET['addr'];
    }

    getStatement($addr);

?>
<!doctype html>
<html lang="en">
<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#ffbf00">
    <meta name="revisit-after" content="30 days" />
    <meta name="robots" content="index, follow, noarchive" />
    <title>VF Cash Explorer</title>

    <link rel="shortcut icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="https://vfcash.uk/favicon.png">
    <link rel="icon" sizes="192x192" href="https://vfcash.uk/favicon.png">
    
    <meta property="og:image" content="https://vfcash.uk/vf.png">
    <meta property="twitter:image:src" content="https://vfcash.uk/vf.png">
    <meta name="image" content="https://vfcash.uk/vf.png">
    <meta itemprop="image" content="https://vfcash.uk/vf.png">
    <meta name="og:image" content="https://vfcash.uk/vf.png">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    <style>
    body
    {
        font-size: 1.09rem;
        font-family: 'Ubuntu', sans-serif;
    }
    td.min
	{
		width: 1%;
		white-space: nowrap;
	}
    </style>

</head>
<body>

    <div class="container-fluid">

    <nav class="navbar navbar-expand-md navbar-light bg-light">
        <a href="https://vfcash.uk"><img src="/light-horiz.svg" width="auto" height="32px" /></a>
    </nav>

<br>
<center>
<b>Transactions for address:</b> <a href="#" id="pubkey" style="word-break:break-all;" data-toggle="tooltip" data-placement="bottom" title="Click to Copy Address to Clipboard." onclick="javascript:CopyAddr('pubkey');"><?php echo $addr; ?></a> (<?php echo number_format(getBalance($addr), 3); ?> <b>VFC</b>)
<?php if($score != ""){echo '<br>(' . $score . ' <b>REP</b>)';} ?>
<?php if($bad != 0){echo ' (<b class="text-danger">' . $bad . '</b> <b>NEG</b>)';} ?>
<br><br>

<div class="d-none d-sm-block">
<form action="/" method="post">
<div class="input-group" style="width:50%;">
    <input class="form-control" type="text" name="ledger" placeholder="address / public key" <?php if(isset($_POST['ledger'])){echo "value=\"".htmlspecialchars($_POST['ledger'])."\"";}?> required>
    <button type="submit" class="btn btn-primary"><b>View Statements</b></button>
</div>
</form>
</div>

<div class="d-block d-sm-none">
<form action="/" method="post">
<div class="input-group .d-block .d-sm-none" style="width:90%;">
    <input style="width:90%;" class="form-control" type="text" name="ledger" placeholder="address / public key" <?php if(isset($_POST['ledger'])){echo "value=\"".htmlspecialchars($_POST['ledger'])."\"";}?> required>
</div>
<button type="submit" class="btn btn-primary"><b>View Statements</b></button>
</form>
</div>

</form>


<?php

    if($ruid != '')
    {
        $p = explode(',', $ruid);
        if(isset($p[5]))
        {
            echo "<hr><b>TXID:</b> " . $p[1] . "<hr>";
            echo "<b>From:</b> " . $p[2] . "<br>";
            echo "<b>To:</b> " . $p[3] . "<br>";
            echo "<b>Sig:</b> " . $p[4] . "<br>";
            echo "<b>Amount:</b> " . @number_format($p[5], 3) . "<hr>";
        }
    }

?>

</center>
<br>
<div class="row">

    <div class="col-md">
    <table class="table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Received</th>
                <th scope="col">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $in; ?>
        </tbody>
    </table>
    </div>

    <div class="col-md">
    <table class="table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Sent</th>
                <th scope="col">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $out; ?>
        </tbody>
    </table>
    </div>
    
</div>

    <br><br>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
    $(function()
    {
        if(window.history.replaceState)
            window.history.replaceState(null, null, window.location.href);

        $('[data-toggle="tooltip"]').tooltip();
    })

    function CopyAddr(id)
    {
        var addr = document.getElementById(id).innerHTML;
        copyTextToClipboard(addr);
    }

    function copyTextToClipboard(text)
    {
        var textArea = document.createElement("textarea");
        textArea.style.position = 'fixed';
        textArea.style.top = 0;
        textArea.style.left = 0;
        textArea.style.width = '2em';
        textArea.style.height = '2em';
        textArea.style.padding = 0;
        textArea.style.border = 'none';
        textArea.style.outline = 'none';
        textArea.style.boxShadow = 'none';
        textArea.style.background = 'transparent';
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
    }
    </script>

</body>
</html>
