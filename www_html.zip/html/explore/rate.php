<?php

    //Start a session
    session_start();


    function hashSanity($hash)
    {
        return str_replace('O', '', str_replace('0', '', str_replace('l', '', preg_replace("/[^A-Za-z0-9]/", '', $hash))));
    }

    function strSanity($str)
    {
        return preg_replace("/[^A-Za-z0-9 ]/", '', $str);
    }


    if(isset($_SESSION['lq']))
    {
        if(time() < $_SESSION['lq'])
        {
            $delta = $_SESSION['lq']-time();
            if($delta <= 3)
            {
                while(time() < $_SESSION['lq'])
                    sleep(1);
            }
            else
            {
                echo "please wait " . abs($delta) . " seconds<meta http-equiv=\"refresh\" content=\"3\">";
                exit;
            }
        }
    }

    function getPublicKey($private_key)
    {
        $na = shell_exec('/usr/bin/vfc getpub ' . escapeshellarg($private_key));
        $p = strstr($na, "Public: ");
        $p = str_replace("Public: ", "", $p);
        return explode("\n", $p, 2)[0];
    }

    function findTransaction($txid)
    {
        $_SESSION['lq'] = time()+1;
        $na = shell_exec('/usr/bin/vfc findtrans ' . escapeshellarg($txid));
        //$_SESSION['lq'] = time()+3;
        return explode(',', $na);
    }

    if(isset($_GET['txid']))
        $_GET['txid'] = strSanity($_GET['txid']);

    $fail = "";
    if(isset($_POST['password']))
    {
        $p = getPublicKey(hashSanity($_POST['password']));
        $t = findTransaction($_GET['txid']);
        if(isset($t[2]))
        {
            if($t[2] == $p)
            {
                file_put_contents('reviews/' . $_GET['txid'], $_POST['sr'], LOCK_EX);
                header('Location: https://vfcash.uk/explore/?addr=' . $p);
                exit;
            }
        }
        $fail = $p . '<br>' . $t[2] . '<br>Wrong private key for TXID: <a href="index.php?uid=' . htmlspecialchars($_GET['txid']) . '">' . htmlspecialchars($_GET['txid']) . '</a>';
    }

    $cset = 0;
    if(file_exists('reviews/' . $_GET['txid']))
        $cset = file_get_contents('reviews/' . $_GET['txid']);

?>
<!doctype html>
<html lang="en">
<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#ffbf00">
    <meta name="revisit-after" content="30 days" />
    <meta name="robots" content="index, follow, noarchive" />
    <title>VF Cash Explorer</title>

    <link rel="shortcut icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="https://vfcash.uk/favicon.png">
    <link rel="icon" sizes="192x192" href="https://vfcash.uk/favicon.png">
    
    <meta property="og:image" content="https://vfcash.uk/vf.png">
    <meta property="twitter:image:src" content="https://vfcash.uk/vf.png">
    <meta name="image" content="https://vfcash.uk/vf.png">
    <meta itemprop="image" content="https://vfcash.uk/vf.png">
    <meta name="og:image" content="https://vfcash.uk/vf.png">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    <style>
    body
    {
        font-size: 1.09rem;
        font-family: 'Ubuntu', sans-serif;
    }
    td.min
	{
		width: 1%;
		white-space: nowrap;
	}
    </style>

</head>
<body>

<div class="container-fluid">

    <nav class="navbar navbar-expand-md navbar-light bg-light">
        <a href="https://vfcash.uk"><img src="/light-horiz.svg" width="auto" height="32px" /></a>
    </nav>

    <br>
    <center>
    <?php

        if($fail != "")
            echo '<b>' . $fail . '</b><br><br>';

    ?>
    <b>Review Transaction:</br><a href="https://vfcash.uk/explore/?uid=<?php echo htmlspecialchars($_GET['txid']); ?>"><?php echo htmlspecialchars($_GET['txid']); ?></a></b>
    <br><br>
    <form action="rate.php?txid=<?php echo $_GET['txid']; ?>" method="post">
    
        <div style="display: inline-block; text-align: left;">

            <div class="form-check">
            <label class="form-check-label">
                <input name="sr" value="0" type="radio" class="form-check-input" <?php if($cset == 0){echo 'checked';} ?>><img src="non.png" width="24px" height="24px" />&nbsp;&nbsp;Not rated / neutral</input>
            </div>
            <div class="col-xs">&nbsp;</div>
            <div class="form-check">
            <label class="form-check-label">
                <input name="sr" value="1" type="radio" class="form-check-input" <?php if($cset == 1){echo 'checked';} ?>><img src="nsat.png" width="24px" height="24px" />&nbsp;&nbsp;Failed to provide service</input>
            </label>
            </div>
            <div class="col-xs">&nbsp;</div>
            <div class="form-check">
            <label class="form-check-label">
                <input name="sr" value="2" type="radio" class="form-check-input" <?php if($cset == 2){echo 'checked';} ?>><img src="sat.png" width="24px" height="24px" />&nbsp;&nbsp;Satisfied with service</input>
            </label>
            </div>
            <div class="col-xs">&nbsp;</div>
            <div class="form-check">
            <label class="form-check-label">
                <input name="sr" value="3" type="radio" class="form-check-input" <?php if($cset == 3){echo 'checked';} ?>><img src="vsat.png" width="24px" height="24px" />&nbsp;&nbsp;Very Satisfied with service</input>
            </label>
            </div>

        </div>
        
        <div class="col-xs">&nbsp;</div>

	<label><b>Enter the Private Key for the address you originally made the payment from:</b></label><br>

        <div class="input-group" style="width:50%;">
            <input name="password" class="form-control" type="password" autocomplete="on" placeholder="<private key>" required>
            <button type="submit" class="btn btn-primary"><b>Submit Review</b></button>
        </div>

    </form>

    <br>

    </center>

<br><br>
</div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
    $(function()
    {
        if(window.history.replaceState)
            window.history.replaceState(null, null, window.location.href);

        $('[data-toggle="tooltip"]').tooltip();
    })

    function CopyAddr(id)
    {
        var addr = document.getElementById(id).innerHTML;
        copyTextToClipboard(addr);
    }

    function copyTextToClipboard(text)
    {
        var textArea = document.createElement("textarea");
        textArea.style.position = 'fixed';
        textArea.style.top = 0;
        textArea.style.left = 0;
        textArea.style.width = '2em';
        textArea.style.height = '2em';
        textArea.style.padding = 0;
        textArea.style.border = 'none';
        textArea.style.outline = 'none';
        textArea.style.boxShadow = 'none';
        textArea.style.background = 'transparent';
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
    }
    </script>

</body>
</html>
