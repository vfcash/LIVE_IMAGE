<?php

    @$host = strtolower($_SERVER["HTTP_HOST"]);
    if($host == "www.vfcash.uk")
    {
        header('Location: https://vfcash.uk');
		exit;
    }
	else if($host == "www.vfcash.uk")
    {
        header('Location: https://vfcash.uk');
		exit;
    }
	else if($host == "www.vfcash.co.uk")
    {
        header('Location: http://vfcash.co.uk');
		exit;
    }
	else if($host == "vfcash.uk")
    {
        //
    }
	else if($host == "vfcash.co.uk")
    {
        //
    }
    else
    {
        exit;
    }

    date_default_timezone_set('UTC');

    if(isset($_POST['ledger']))
    {
        header('Location: /explore/?addr='.urlencode($_POST['ledger']));
        exit;
    }

    $na = shell_exec('/usr/bin/vfc difficulty');
    $difficulty = explode("\n", str_replace("Difficulty: ", "", strstr($na, "Difficulty: ")), 2)[0];
    $dscale = 18;

    $age = time() - strtotime('2019-04-23 00:00:00');
    $tdays = floatval($age)/86400.0;
    $years = floor((floatval($age)/86400.0)/365.0);
    $days = $tdays - (floor($years)*365.0);
    $months = $days / 30.4167;

    $diffpercent = 100-(555.555555556 * $difficulty);

?>
<!DOCTYPE html>
<html lang="en" prefix="og: http://ogp.me/ns#"> 
<head>
    <meta name="darkreader-lock"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#ffbf00">
    <meta name="revisit-after" content="30 days" />
    <meta name="robots" content="index, follow, noarchive" />
    <title>VF Cash (VFC)</title>

    <link rel="canonical" href="https://vfcash.uk" />

    <link rel="shortcut icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon" href="https://vfcash.uk/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="https://vfcash.uk/favicon.png">
    <link rel="icon" sizes="192x192" href="https://vfcash.uk/favicon.png">
    
    <meta property="og:image" content="https://vfcash.uk/favicon.png">
    <meta property="twitter:image:src" content="https://vfcash.uk/favicon.png">
    <meta name="image" content="https://vfcash.uk/favicon.png">
    <meta itemprop="image" content="https://vfcash.uk/favicon.png">
    <meta name="og:image" content="https://vfcash.uk/favicon.png">

    <meta name="description" content="VF Cash (VFC), a secure and fast digital payments system.">
    <meta itemprop="name" content="VF Cash (VFC), a secure and fast digital payments system.">
    <meta name="og:description" content="VF Cash (VFC), a secure and fast digital payments system.">

    <meta name="og:title" content="VF Cash (VFC)">
    <meta name="og:site_name" content="VF Cash (VFC)">
    <meta name="og:type" content="website">

    <meta name="og:url" content="https://vfcash.uk">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/jquery.js"></script>

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    
    <style>
        body{color: #fff;background-color:#000!important;font-size: 1.8em;}
        a{color: #ffbf00;font-weight: bold;}
        a img{outline:none!important;border:none!important;}
    </style>
</head>
<body>
<img src="favicon.png" width=3 height=3 style="z-order:-9999;position:absolute;" />

<div id="preloader"></div>
<header class="navbar navbar-inverse navbar-fixed-top " role="banner">
<div class="container">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <i class="fa fa-bars"></i>
        </button>
        <a class="navbar-brand" href="#" style="cursor:pointer;" onclick="javascript:popWallet();" data-toggle="tooltip" data-html="true" data-placement="bottom" title="<b>Click here to launch the Web-Wallet</b>">
        <h1><img src="favicon-light.png" height="32px" class="bounce-in" /> VF CASH</h1></a>
    </div>
    <div class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
            <li><a href="/explore" target="_blank">Explorer</a></li>
            <li><a style="cursor:pointer;" onclick="javascript:popWallet();" target="_blank">Wallet</a></li>
            <li><a href="https://github.com/vfcash" target="_blank">Github</a></li>
        </ul>
    </div>
</div>
</header>

<div id="content-wrapper">

    <section class="white">
        <div class="gap"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 fade-up">
                    VF Cash is a <a href="https://en.wikipedia.org/wiki/Digital_currency" rel="nofollow" target="_blank">digital currency</a> project of <?php echo number_format($years, 0); if($years > 1){echo ' years';}else{echo ' year';}?> and <?php echo number_format($months, 0); if($months > 1 || floor($months) == 0){echo ' months';}else{echo ' month';}?> old that intends to address the issue of <a href="https://en.wikipedia.org/wiki/Microtransaction" rel="nofollow" target="_blank">micro-transactions</a>.
                    <br><br>
                    <ul>
                        <li>The VF Cash network has perceptibly instant transactions with no fees.</li>
                        <li>Currency can be mined offline allowing for private transactions from mined addresses.</li>
                        <li>Webmasters can monetize their websites in a non-invasive way that is compliant with HTML5 standards.</li>
                    </ul>
                    Learn more about the VF Cash project over at the <a href="https://james-william-fletcher.medium.com/creating-a-digital-currency-f970fc0f1dce" target="_blank">Medium article here</a> or the <a href="https://github.com/vfcash/VFC-Core/blob/master/FAQ.md" rel="nofollow" target="_blank">FAQ.</a>

                </div>
            </div>
        </div>
    </section>

    <section class="divider-section" style="background-color:#000;">
    <a name="g"></a>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <hr>
                    <center><h3 class="main-title">Minted</h3></center>
                    <hr>
                    <br>
                    <div id="chart"></div>
                </div>
                <div class="col-md-6">
                    <hr>
                    <center><h3 class="main-title">Transactions</h3></center>
                    <hr>
                    <br>
                    <div id="chart2"></div>
                </div>
            </div>
        <center>
        <hr>
        <h3 class="main-title">Minting Difficulty - <b><?php echo number_format($diffpercent, 0); ?>%</b></h3>
        Next Network Difficulty: <b style="color:#ffbf00;">
        <?php
            echo number_format($diffpercent, 0);
        ?>%</b> in 10 minutes
        <hr>
        <div class="row">
            <div class="col-md-6">
                To decrease the difficulty towards <b style="color:#ffbf00;">(0%)</b> pay VFC into:<br>
                <a id="pubkey2" data-toggle="tooltip" data-placement="bottom" data-html="true" title="<b>Click to Copy Address</b>" style="word-break:break-all;font-weight:normal;" onclick="javascript:CopyAddr('pubkey2');" href="#g">24KvoteVFC7JsTiFaGna9F6RhtMWdB7MUa3wZoVNm7wH3</a><br>
                <b style="color:#ffbf00;"><?php echo number_format(explode(" ", str_replace("(", "", strstr(strstr($na, "24KvoteVFC7JsTiFaGna9F6RhtMWdB7MUa3wZoVNm7wH3 "), "(")), 2)[0]); ?></b> <b>VFC</b>
            </div>
            <div class="col-md-6">
                To increase the difficulty towards <b style="color:#ffbf00;">(100%)</b> pay VFC into:<br>
                <a id="pubkey1" data-toggle="tooltip" data-placement="bottom" data-html="true" title="<b>Click to Copy Address</b>" style="word-break:break-all;font-weight:normal;" onclick="javascript:CopyAddr('pubkey1');" href="#g">q15voteVFCf7Csb8dKwaYkcYVEWa2CxJVHm96SGEpvzK</a><br>
                <b style="color:#ffbf00;"><?php echo number_format(explode(" ", str_replace("(", "", strstr(strstr($na, "q15voteVFCf7Csb8dKwaYkcYVEWa2CxJVHm96SGEpvzK "), "(")), 2)[0]); ?></b> <b>VFC</b>
            </div>
        </div>
        <br>
        <a onclick="javascript:window.location.replace('https://vfcash.uk/?<?php echo mt_rand(); ?>#g');" href="/?<?php echo mt_rand(); ?>#g">Click to Refresh Graphs</a><br>
        </center>
        </div>
    </section>

</div>

<script src="js/plugins.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>   
<script src="js/init.js"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script>
function popWallet()
{
    var w = 560;
    var h = 600;
    var left = (screen.width/2)-(w/2);
    var top = (screen.height/2)-(h/2);
    window.open("/wallet", "vfcwallet", "top="+top+", left="+left+", width="+w+", height="+h+", resizable=yes, toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, copyhistory=no").blur();
}

function CopyAddr(id)
{
    var addr = document.getElementById(id).innerHTML;
    copyTextToClipboard(addr);
}

function copyTextToClipboard(text)
{
    var textArea = document.createElement("textarea");
    textArea.style.position = 'fixed';
    textArea.style.top = 0;
    textArea.style.left = 0;
    textArea.style.width = '2em';
    textArea.style.height = '2em';
    textArea.style.padding = 0;
    textArea.style.border = 'none';
    textArea.style.outline = 'none';
    textArea.style.boxShadow = 'none';
    textArea.style.background = 'transparent';
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
}

var options =
{
    chart: {
        type: 'line',
        height: 220,
        background: '#333'
    },
    colors: ['#77eaab'],
    stroke: {
        width: 1,
        curve: 'stepline',
    },
    yaxis: {
        labels: {
            formatter: function(val, index)
            {
                if(val < 0)
                    return "";
                else
                    return val.toLocaleString(undefined,{minimumFractionDigits:3});
            }
        }
    },
    theme: {
        mode: 'dark', 
    },
    xaxis: {
        show: false,
        labels:
        {
            formatter: function(val, index)
            {
                if(val < 0)
                    return "";
                else
                    return (360-val.toFixed(0))*-1 + " Minutes";
            },
            show: false
        },
        tooltip: {
            enabled: true
        }
    },
    tooltip: {
        x:
        {
            show: false
        },
        y:
        {
            formatter: function(value, { series, seriesIndex, dataPointIndex, w })
            {
                return value.toFixed(3) + " VFC";
            }
        }
    },
    dataLabels: {
        enabled: false
    },
    series: [{
        name: "Minted",
<?php

    $o = 'data: [';
    $lines = explode(PHP_EOL, file_get_contents('/var/www/html/graphdata/minted_pm.txt'));
    $ll = 0;
    foreach($lines as $l)
    {
        if($l == "")
            continue;

        if($ll != 0)
        {
            $fv = $l-$ll;
            if($fv < 0)
                $fv = 0;
            $o .= number_format($fv, 3, '.', '') . ',';
        }
        $ll = $l;
        
    }
    echo rtrim($o, ',') . ']';

?>
    }],
    markers: {
        hover: {
            sizeOffset: 4
        }
    },
}

var options2 =
{
    chart: {
        type: 'line',
        height: 220,
        background: '#333'
    },
    colors: ['#77eaab'],
    stroke: {
        width: 1,
    curve: 'stepline',
    },
    yaxis: {
    labels: {
        formatter: function(val, index)
        {
        if(val < 0)
            return "";
        else
            return val.toLocaleString();
        }
    }
    },
    theme: {
        mode: 'dark', 
    },
    xaxis: {
        show: false,
        labels: {
            formatter: function(val, index)
            {
                if(val < 0)
                    return "";
                else
                    return (360-val.toFixed(0))*-1 + " Minutes";
            },
            show: false
        },
        tooltip: {
            enabled: true
        }
    },
    tooltip: {
        x:
        {
            show: false
        }
    },
    dataLabels: {
        enabled: false
    },
    series: [{
        name: "Transactions",
<?php

    $o = 'data: [';
    $lines = explode(PHP_EOL, file_get_contents('/var/www/html/graphdata/trans_pm.txt'));
    $ll = 0;
    foreach($lines as $l)
    {
        if($l == "")
            continue;

        if($ll != 0)
            $o .= number_format(($l-$ll)/144, 0, '', '') . ',';
        $ll = $l;
        
    }
    echo rtrim($o, ',') . ']';

?>
    }],
    markers: {
        hover: {
            sizeOffset: 4
        }
    },
}

var chart1 = new ApexCharts(document.querySelector("#chart"), options);
var chart2 = new ApexCharts(document.querySelector("#chart2"), options2);

$(document).ready(function()
{
    $('[data-toggle="tooltip"]').tooltip();
    chart1.render();
    chart2.render();
});
</script>

</body>
</html>
